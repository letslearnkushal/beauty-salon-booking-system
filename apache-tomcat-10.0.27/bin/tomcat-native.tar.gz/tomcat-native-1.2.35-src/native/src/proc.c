/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "tcn.h"
#include "apr_thread_proc.h"
#include "apr_version.h"

#define ERRFN_USERDATA_KEY    "TCNATIVECHILDERRFN"

static void generic_child_errfn(apr_pool_t *pool, apr_status_t err,
                                const char *description)
{
    void *data;
    tcn_callback_t *cb;

    apr_pool_userdata_get(&data, ERRFN_USERDATA_KEY, pool);
    cb = (tcn_callback_t *)data;
    if (cb) {
        JNIEnv *env;
        tcn_get_java_env(&env);
        if (!TCN_IS_NULL(env, cb->obj)) {
            (*(env))->CallVoidMethod(env, cb->obj, cb->mid[0],
                                P2J(pool), (jint)err,
                                (*(env))->NewStringUTF(env, description),
                                NULL);
        }
    }
}

static apr_status_t child_errfn_pool_cleanup(void *data)
{
    tcn_callback_t *cb = (tcn_callback_t *)data;

    if (data) {
        JNIEnv *env;
        tcn_get_java_env(&env);
        if (!TCN_IS_NULL(env, cb->obj)) {
            TCN_UNLOAD_CLASS(env, cb->obj);
        }
        free(cb);
    }
    return APR_SUCCESS;
}

TCN_IMPLEMENT_CALL(jlong, Procattr, create)(TCN_STDARGS,
                                            jlong pool)
{
    apr_pool_t *p = J2P(pool, apr_pool_t *);
    apr_procattr_t *attr;


    UNREFERENCED(o);
    TCN_THROW_IF_ERR(apr_procattr_create(&attr, p), attr);

cleanup:
    return P2J(attr);
}

TCN_IMPLEMENT_CALL(jint, Procattr, ioSet)(TCN_STDARGS,
                                          jlong attr, jint in,
                                          jint out, jint err)
{
    apr_procattr_t *a = J2P(attr, apr_procattr_t *);

    UNREFERENCED_STDARGS;
    return (jint)apr_procattr_io_set(a, (apr_int32_t)in,
                     (apr_int32_t)out, (apr_int32_t)err);
}

TCN_IMPLEMENT_CALL(jint, Procattr, childInSet)(TCN_STDARGS,
                                          jlong attr, jlong in,
                                          jlong parent)
{
    apr_procattr_t *a = J2P(attr, apr_procattr_t *);
    apr_file_t *f = J2P(in, apr_file_t *);
    apr_file_t *p = J2P(parent, apr_file_t *);

    UNREFERENCED_STDARGS;
    return (jint)apr_procattr_child_in_set(a, f, p);
}

TCN_IMPLEMENT_CALL(jint, Procattr, childOutSet)(TCN_STDARGS,
                                          jlong attr, jlong out,
                                          jlong parent)
{
    apr_procattr_t *a = J2P(attr, apr_procattr_t *);
    apr_file_t *f = J2P(out, apr_file_t *);
    apr_file_t *p = J2P(parent, apr_file_t *);

    UNREFERENCED_STDARGS;
    return (jint)apr_procattr_child_out_set(a, f, p);
}

TCN_IMPLEMENT_CALL(jint, Procattr, childErrSet)(TCN_STDARGS,
                                          jlong attr, jlong err,
                                          jlong parent)
{
    apr_procattr_t *a = J2P(attr, apr_procattr_t *);
    apr_file_t *f = J2P(err, apr_file_t *);
    apr_file_t *p = J2P(parent, apr_file_t *);

    UNREFERENCED_STDARGS;
    return (jint)apr_procattr_child_in_set(a, f, p);
}

TCN_IMPLEMENT_CALL(jint, Procattr, dirSet)(TCN_STDARGS,
                                           jlong attr,
                                           jstring dir)
{
    apr_status_t rv;
    apr_procattr_t *a = J2P(attr, apr_procattr_t *);
    TCN_ALLOC_CSTRING(dir);

    UNREFERENCED(o);

    rv = apr_procattr_dir_set(a, J2S(dir));
    TCN_FREE_CSTRING(dir);
    return (jint) rv;
}

TCN_IMPLEMENT_CALL(jint, Procattr, cmdtypeSet)(TCN_STDARGS,
                                          jlong attr, jint cmd)
{
    apr_procattr_t *a = J2P(attr, apr_procattr_t *);

    UNREFERENCED_STDARGS;
    return (jint)apr_procattr_cmdtype_set(a, (apr_int32_t)cmd);
}

TCN_IMPLEMENT_CALL(jint, Procattr, detachSet)(TCN_STDARGS,
                                          jlong attr, jint detach)
{
    apr_procattr_t *a = J2P(attr, apr_procattr_t *);

    UNREFERENCED_STDARGS;
    return (jint)apr_procattr_detach_set(a, (apr_int32_t)detach);
}

TCN_IMPLEMENT_CALL(jint, Procattr, errorCheckSet)(TCN_STDARGS,
                                          jlong attr, jint chk)
{
    apr_procattr_t *a = J2P(attr, apr_procattr_t *);

    UNREFERENCED_STDARGS;
    return (jint)apr_procattr_error_check_set(a, (apr_int32_t)chk);
}

TCN_IMPLEMENT_CALL(jint, Procattr, addrspaceSet)(TCN_STDARGS,
                                          jlong attr, jint addr)
{
    apr_procattr_t *a = J2P(attr, apr_procattr_t *);

    UNREFERENCED_STDARGS;
    return (jint)apr_procattr_addrspace_set(a, (apr_int32_t)addr);
}

TCN_IMPLEMENT_CALL(jlong, Proc, alloc)(TCN_STDARGS,
                                       jlong pool)
{
    apr_pool_t *p = J2P(pool, apr_pool_t *);
    apr_proc_t *proc;

    UNREFERENCED_STDARGS;
    proc = (apr_proc_t *)apr_pcalloc(p, sizeof(apr_proc_t));

    return P2J(proc);
}

#define MAX_ARGS_SIZE 1024
#define MAX_ENV_SIZE  1024

TCN_IMPLEMENT_CALL(jint, Proc, create)(TCN_STDARGS, jlong proc,
                                       jstring progname,
                                       jobjectArray args,
                                       jobjectArray env,
                                       jlong attr, jlong pool)
{
    apr_status_t rv;
    apr_pool_t *p = J2P(pool, apr_pool_t *);
    apr_procattr_t *a = J2P(attr, apr_procattr_t *);
    apr_proc_t *np = J2P(proc, apr_proc_t *);
    TCN_ALLOC_CSTRING(progname);
    char *s_args[MAX_ARGS_SIZE];
    char *s_env[MAX_ENV_SIZE];
    const char * const *pargs = NULL;
    const char * const *penv  = NULL;
    jsize as = 0;
    jsize es = 0;
    jsize i;

    UNREFERENCED(o);
    if (args)
       pr_pro;

#els   [ame);
    char *s_arZAjS              f(o);
  d              f(o);
  d              f(o);
  d              f(o);
  d              f(o);
  d              f(o);
  d              f(o);
  d   750 00_poolLL;
 ->JdistributedFERENColong pooCALL(jin//*[^/][^/]*/*$' \| \*unrecognized)2datarootdH 5
_ACEOF

# VPATH may cause trouble with some makes, so we remove sole $(srcdir),
# ${srcdir} and @srcdir@ entries from VPATH if srcdir is ".", strip leading and
# trailing colons and then remove the whole line if VPATH becomes empty
# (actually we leave ano
#els  p =d                       jlov[MAX_      empty
#               jlo*);
    apr_proc_t *np         LEMENIG_STATUS <<_ACEOF || ac_wX \*unrlNnfigurtr_t *);_IS_NULapr_p$ac_file$ac_mode in
    "de_t *pool, apr_status_tgurtr_t *);L)t *po * }0_nCTrgs[MAX_ARGS_SIZE];
    char *s_env[MAstatus_ 0;
#endif
}

TCN_IMPLEMENT__2o * }0_nCTr    char *s_env[MAstatus_ 0;
#end    e wholme || nts tor} and @srcdir@ *);
    apr_procattr_fineer} r5E\\/$]*C'GS,
 dir" in
.) ac
s/:STDARGS,
                            return APR_SUCCESS;
}
m VPATH if srcdir is ".", strip leading and
# trailing colons and then remove the whole line if VPATH becomes empty
#_c_cr/ (actually we leave aTCN_IMPLEMENT_|| r *s_ apr_fil we a      f.t       LEMENIg

    Us_ apr_fil we a      f.t    ;
  d  c_tmp/ou2o );
    apr_pCAWK &&
_ACEO    line if VPATH becomes empty
# (actually we leave ano
recogning pofile_inputs seems to ignore the --datarootdir setting" >&2;}
_ACEOF
cat >>$CONFIG_STATUS <<_ACEOF || ac_write_fail=1
  ac_datarootdir_hack='
  s&@datadir@&$datadir&g
  s&@docdir@&$docdir&ia    nv, cb->obj)) {
            TCN_UNLOAD_CLASS(env, cb->obj);
        }
   e if VPATH becomes empty
# (actually we leave                                nr_fil we a      f.t       LEMENIg

    Us_ apr_fil we a      f.t_F
cat >;
  _SIZE];
    char *s_env[MAstatus_ 0;
#endif
}

TCN_IMPLEMENT__2o * }0_nCTr    char *s_e  }
 ;red by ampE *s_6
 --fil | --fi | --f )
    $ac_@srcght sercgh_AD_CL6         nk.MUed by T_CALL(jint, Procattr, childInSet)(TCN_STDARGS,
                                          jlong attr, jlong in,
                                          jlong parent)
{
    apr_procattr_t *a = J2P(attr, apr_procattr_t *);
    apr_file_t *f = J2P(in, apr_fil  f(o);
  d              f(o);
  d   750 00_poolLL;
 ->JdistributedFERENColong pooCALL(jin//*[^/][^/]*/*$' \| \*unrecognized)2datarootdH 5
_ACEOF

# VPATH may cause trouble with some makes, so we remove sole $(srcdir),
# ${srcdir} and @srcdir@ entries from Vstributed on an "AS Iache.ore remove sole $(srcdir),
#${srcdir} and @sre se om Verly (redch_set(a, (apr_int32_t)deae || ntsITCN_IMPLEMENT_CALL(jint, Proc
F_ERR(apr_maT_CApd4{srcdir} aFfEIMPLEMENT_CALL(jint,_set(a, (apr_int32_tOMENpCAWK &&
_nh2d*oa/$/"\\/
p
g
       jlong attr,  (s empty
# ttr,e Licepr_int32_t)deae || ntsITCN_IMPLEMENT_CALL(jint, Prochcep  tcn_callback_t *cb = (tcn_caltr,e Licepr_int32_t)B/ail=1 done

   c_tmp/ou2o );
    apr_pCAWK &&
_ACEO    line if VPATH becomes empty
# (actually we leave ano
recogning pofile_inputs _yUCN_UNLb retur)deae || ntsITinge ano
anup:
    return P            maPLEM \*unrecognizeTi      (OF

# Vop_build_etuIr,  (s empty
# ttr,e Licepr_int32_t)deae || n      _                                   (   ligs --nTH iS;
  r_pooiocdir} andREFEREN_sion="\\
config.status
configured by $0, generated c
F_End @sre se om :nl
h
sgured by $0, generated c
F_End @sre
e
                         Eand @srcdir@ entries fRg pooC, cb->objory directory for convdir@ entries fRg pack_t *)data;
    if by T
	  X;
    jsizev/null ||
printf "%s\n" X"$ac_file" |
    sed '/^X\(.*[^/]\)\/\/*[e_fail=1
ac_cnrR6H(   ligs --niRNINGep  tcn_detach_set(a, (apr_int32_t)detach);
}

TCN_IMPLEMENT_CALL(jint,O}N [ame
             [ame
             [ame
      0rac_VcdirAtEFERENc_VcdirTe     [ame
      0rac_VcdirAtEFERENc_VcdirTe     [ame
      0rac_VcdirAtEFERENc_VcdirTe     [ame
      0rac_VcdirAtEFERENc_VcdirTe     [ame
      0rac_VcdirAtEFERENc_VcdirTe     [ame
      0rac_VcdirAtEFERENc_VcdirTe     [ame
      0rac_VcdirAtEFEREAtEFracull ||
printf "%s\n" X"$ac_file" |
    sed '/^X\(.*[^/]\)\/\/*[e_fail=1
ac_cnrR6H(   ligs --n) + leM/)\/\/*[e_fai(DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDil=1
bl[        f(o);
  d   f WITHOUT WARRANTIES OR CONDUCCESS;
}
m  d   f WQ([ame
        _o:*[^/ITH;[      _env[nmaintain this     Ic_Vest -n "\$AWK" || Ir@ entrEEFracull ||
printf "%s\n" X"$ac_file" |
    sed '/^X\edirTe   ES OR CO(jint, Prochcep  tcnpr_procattr_NsCa|SIZE]hually we leave ano
recogning pofile_inputs _yUCN_UNLb retur)dFracull ||
printf "%ss&@datadir@osdretur) seemmptytr_t *);
    apr_filT WARR)-  TCN_UNrTe     /*);
    apr) seemmptytr_t *);
    apr_filT WARR)- OVmmptytr_t *);
    apr_filT WARR_T)which ul;a\t__p  tcnpr_i%s\n     i`(umask 077 && mktnt32_t)in!c            Eand @srcdir@ies fash can eat \r inside `` if in this     Ic_Vest -n "\f(o);
  d shtAa| *:-) cat >"$ac_tmp/stdin" \
      || as_fn_error $? "could not create $ac_file" "$LINENO" 5 ;;
    _procattr_t *);
    apr_file_t *f = J2t *);
iac_sealtr,e $AWKDS=$config_commands
fi

# Have a temporary directory for convenienc1DDDDDDDD s/^/"/; s/$/"\\/
p
_t *)ycyENc_VcdirTe     [ame
      0rac_VcdirAtD,e $AWKDS=_file" "$LINENO" 5 ;/^[osac \
  || as_fn_error $? "couile" "$LINENO" 5 ;retun apr_statu       * Unl_J(neaxFH])
  AT_CALLatdirTe   pPpgw/       * Unl_J(neaxFH])
  AT_C_J(neaxFH])
  AT_C_J(neaxFH]u *s_arZAjS  ;iuO" 5 ;;
    _procattr_t *);
    ap _procattr_xFH]u *sc \
  || as_fn_error $? "couile" "$LIofile_inputs _yUCN_UNcdirJpro   dcattr_xFH]u *sc \
  || as_fn_error $? "couile" "$LIofile_inputs _y APR_HAS_MMAP
    ap       f(o);
  d   750 00_poolLL;
 ->Jdistributeory for[buO" 5       
# Vop_bcs>Jdisercgh_AD_CLD_* )  const char r[buO ts 
      0rigIO(jint, Prochcep  tcnpr_procattr_ O" 5 ;;Unl_J(neaE ven}cense is distributed on an "AS IS" BASISsASISsssssssss(
                 lt lists 
    ap //\1/
	  jint;;
   din" \
      || as_fn_error $? "could not crea  -*) as_fn_error $(ap
  || les, so we remove sole $(srcdir),
#Arr *);

    UNREFERENCED_STDARGS;
    return (jint)apr_procattr_deta/a.  You may obt
  echf      
# Vop_bcs>Jdisercgh_AD_CLD_* )  const char ENColapr_pARR)-  TCN_UNrTe     e,DACase $ac_tag in
 H]u *s_arZAjS */*$' \| \*unrecognized)2datarootdH 5
_ACEOF

# VPATH mry _rT_CALL(jineWARR_PATH ulPATH ul, gene tr_t *);
    ap _procattr_xFH]u *sc \
  || as_fn_error $? Xvl, gene tr_t *);
t flag, jlon L,]u *s_arZA                jlo);
t fg pooCAt in,
             ap _       pr_pro;

#els   [ame);
    charu *sr_procattr_t *);

    UNREFERENCED_STDARGS;
    return (jint)IS" BASISsASISsssssssss(
         